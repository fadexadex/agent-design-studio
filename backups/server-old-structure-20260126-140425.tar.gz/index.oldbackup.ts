/**
 * Agent Design Studio - Backend Server
 * 
 * Main entry point for the backend application.
 * 
 * Architecture:
 * - /api - API layer (routes, middleware, server config)
 * - /core - Business logic (agent, workflow, editor, controllers, services)
 * - /shared - Shared utilities (types, constants, helpers, config)
 */

import { config } from 'dotenv';

// Load environment variables from .env.local FIRST
config({ path: '.env.local' });

import express from 'express';
import cors from 'cors';

// Import from old structure (still working) until we fully migrate
import workflowRoutes, { orchestratorMap } from './routes/workflowRoutes';
import { initEditorRoutes } from './routes/editorRoutes';
import {
  generateScript,
  generateVideo,
  getJobStatus,
  getVideo,
  getPreview,
  healthCheck
} from './controllers';

const app = express();
const PORT = process.env.PORT || 3001;

// Debug: Check if API key is loaded
console.log('🔑 GEMINI_API_KEY loaded:', process.env.GEMINI_API_KEY ? 'Yes (length: ' + process.env.GEMINI_API_KEY.length + ')' : 'No');

// Middleware
app.use(cors({
  origin: ['http://localhost:3000', 'http://127.0.0.1:3000'],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));

// API Routes
app.use('/api/workflow', workflowRoutes);
app.use('/api/editor', initEditorRoutes(orchestratorMap));

// Route handlers
app.post('/api/generate-script', generateScript);
app.post('/api/generate', generateVideo);
app.get('/api/status/:jobId', getJobStatus);
app.get('/api/video/:jobId', getVideo);
app.get('/api/preview/:filename', getPreview);
app.get('/api/health', healthCheck);

// Start server
app.listen(PORT, () => {
  console.log(`🎬 Agent Design Studio Backend running on http://localhost:${PORT}`);
  console.log(`   Health check: http://localhost:${PORT}/api/health`);
});

export default app;
